module.exports = {
  publicPath: '/',
  productionSourceMap: false,
  lintOnSave: false,
  devServer: {
    port: 8880, 
  }
}